const products=[
{name:"Apple",price:120,unit:"1 kg",emoji:"🍎"},
{name:"Banana",price:60,unit:"1 dozen",emoji:"🍌"},
{name:"Anar",price:160,unit:"1 kg",emoji:"🍎"},
{name:"Amrud",price:80,unit:"1 kg",emoji:"🍐"},
{name:"Kalingad",price:40,unit:"1 pc",emoji:"🍉"},
{name:"Nariyal",price:40,unit:"1 pc",emoji:"🥥"}
];
let cart=[];
function renderProducts(){document.getElementById("productGrid").innerHTML=products.map((p,i)=>`
<div class="card"><div class="pic">${p.emoji}</div><h3>${p.name}</h3><div class="price">₹${p.price} <small>/ ${p.unit}</small></div><button class="add" onclick="add(${i})">Add to Cart</button></div>`).join("")}
function add(i){let x=cart.find(a=>a.i===i);x?x.qty++:cart.push({i,qty:1});renderCart()}
function change(i,d){let x=cart.find(a=>a.i===i);if(!x)return;x.qty+=d;if(x.qty<=0)cart=cart.filter(a=>a.i!==i);renderCart()}
function renderCart(){let total=0,count=0;document.getElementById("cartItems").innerHTML=cart.length?cart.map(x=>{let p=products[x.i],s=p.price*x.qty;total+=s;count+=x.qty;return `<div class="item"><div><b>${p.name}</b><br>₹${p.price} × ${x.qty}</div><div class="qty"><button onclick="change(${x.i},-1)">−</button> ${x.qty} <button onclick="change(${x.i},1)">+</button></div></div>`}).join(""):"<p>Your cart is empty.</p>";document.getElementById("total").textContent=total;document.getElementById("cartCount").textContent=count}
function openCart(){document.getElementById("cart").classList.add("open");document.getElementById("overlay").classList.add("open")}
function closeCart(){document.getElementById("cart").classList.remove("open");document.getElementById("overlay").classList.remove("open")}
function orderWhatsApp(){let total=cart.reduce((s,x)=>s+products[x.i].price*x.qty,0);if(total<50){alert("Minimum order is ₹50.");return}let text="Hello The Fruit Hub, I want to order:%0A"+cart.map(x=>`${products[x.i].name} x ${x.qty}`).join("%0A")+`%0ATotal: ₹${total}`;window.open("https://wa.me/?text="+text,"_blank")}
renderProducts();renderCart();
